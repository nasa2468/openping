# Contributing

Contributions are welcome. Please open an issue before large changes, keep pull requests focused, and include tests for behavior changes.

Before submitting a pull request, run:

```bash
go fmt ./...
go test ./...
go vet ./...
```

By contributing, you agree that your contributions are licensed under the MIT License.
