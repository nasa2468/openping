# OpenPing

OpenPing is a small, self-hosted HTTP/HTTPS and TCP availability monitor. It stores check results in SQLite and includes a lightweight dashboard and JSON API.

## Features

- HTTP/HTTPS and TCP connectivity checks
- Configurable intervals and timeouts
- SQLite persistence with WAL mode and automatic retention cleanup
- Dashboard plus JSON API
- Health and readiness endpoints
- Graceful shutdown for containers and service managers
- Docker and Docker Compose support

## Quick start

Requires Go 1.23+ and a C compiler for the SQLite driver.

Before publishing, replace `YOUR_GITHUB_USERNAME` in `go.mod` and imports with your GitHub account or organization name.

```bash
cp config.example.yaml config.yaml
go run ./cmd/openping
```

Open [http://localhost:8080](http://localhost:8080). On Windows PowerShell, use `Copy-Item config.example.yaml config.yaml`.

## Configuration

```yaml
server:
  address: ":8080"
database: "openping.db"
retention_days: 30
targets:
  - name: Example site
    type: http
    address: https://example.com/health
    interval_seconds: 30
    timeout_seconds: 10
  - name: DNS
    type: tcp
    address: 1.1.1.1:53
    interval_seconds: 30
    timeout_seconds: 5
```

Target types are `http` and `tcp`. HTTP endpoints are considered up for 2xx or 3xx responses. Target names must be unique; timeout must not exceed interval.

## API

- `GET /api/latest` — latest result for every configured target
- `GET /api/recent` — up to 100 latest records across all targets
- `GET /healthz` — process liveness
- `GET /readyz` — SQLite readiness

## Docker

Set the database path to `/data/openping.db` in `config.yaml`, then run:

```bash
docker compose up -d --build
```

The named Docker volume retains SQLite data across container recreation.

## Development

```bash
go fmt ./...
go test ./...
go vet ./...
```

## Security notes

OpenPing is designed for a trusted, self-hosted network. Monitoring targets can cause outbound network requests; do not grant untrusted users write access to `config.yaml`. Put the dashboard behind a reverse proxy or private network if it is exposed beyond your local environment.

## License

[MIT](LICENSE)
