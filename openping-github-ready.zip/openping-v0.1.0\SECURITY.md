# Security policy

Please do not report security vulnerabilities in public issues. Report them privately to the repository maintainer with a description, reproduction steps, and potential impact. The project aims to acknowledge reports within seven days.
