package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/signal"
	"sort"
	"syscall"
	"time"

	"github.com/YOUR_GITHUB_USERNAME/openping/internal/checker"
	"github.com/YOUR_GITHUB_USERNAME/openping/internal/storage"
	"gopkg.in/yaml.v3"
)

type Config struct {
	Server        ServerConfig `yaml:"server"`
	Database      string       `yaml:"database"`
	RetentionDays int          `yaml:"retention_days"`
	Targets       []Target     `yaml:"targets"`
}
type ServerConfig struct { Address string `yaml:"address"` }
type Target struct {
	Name string `yaml:"name"`; Type string `yaml:"type"`; Address string `yaml:"address"`
	IntervalSeconds int `yaml:"interval_seconds"`; TimeoutSeconds int `yaml:"timeout_seconds"`
}
type apiResult struct { Target string `json:"target"`; Up bool `json:"up"`; LatencyMs int64 `json:"latency_ms"`; StatusCode int `json:"status_code,omitempty"`; Error string `json:"error,omitempty"`; CheckedAt time.Time `json:"checked_at"` }

func main() {
	cfg, err := loadConfig("config.yaml"); if err != nil { log.Fatal(err) }
	store, err := storage.Open(cfg.Database); if err != nil { log.Fatal(err) }; defer store.Close()
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM); defer stop()
	for _, target := range cfg.Targets { go monitor(ctx, target, store) }
	go retentionLoop(ctx, store, cfg.RetentionDays)

	mux := http.NewServeMux(); mux.Handle("/", http.FileServer(http.Dir("web"))); mux.HandleFunc("/healthz", healthHandler); mux.HandleFunc("/readyz", readyHandler(store)); mux.HandleFunc("/api/recent", recentHandler(store)); mux.HandleFunc("/api/latest", latestHandler(store))
	server := &http.Server{Addr: cfg.Server.Address, Handler: loggingMiddleware(mux), ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 10 * time.Second, WriteTimeout: 10 * time.Second, IdleTimeout: 60 * time.Second}
	go func() { log.Printf("OpenPing listening on %s", cfg.Server.Address); if err := server.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) { log.Printf("server: %v", err); stop() } }()
	<-ctx.Done(); shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second); defer cancel(); _ = server.Shutdown(shutdownCtx)
}

func loadConfig(path string) (Config, error) {
	data, err := os.ReadFile(path); if err != nil { return Config{}, err }; var cfg Config; if err := yaml.Unmarshal(data, &cfg); err != nil { return Config{}, err }
	if cfg.Server.Address == "" { cfg.Server.Address = ":8080" }; if cfg.Database == "" { cfg.Database = "openping.db" }; if cfg.RetentionDays == 0 { cfg.RetentionDays = 30 }; if cfg.RetentionDays < 1 { return Config{}, errors.New("retention_days must be positive") }; if len(cfg.Targets) == 0 { return Config{}, errors.New("configuration must define at least one target") }
	seen := map[string]bool{}
	for i := range cfg.Targets { t := &cfg.Targets[i]; if t.Name == "" || seen[t.Name] { return Config{}, errors.New("target names must be non-empty and unique") }; seen[t.Name] = true; if t.Type != "http" && t.Type != "tcp" { return Config{}, fmt.Errorf("target %q has invalid type %q", t.Name, t.Type) }; if t.Address == "" { return Config{}, fmt.Errorf("target %q has no address", t.Name) }; if t.Type == "http" { u, err := url.ParseRequestURI(t.Address); if err != nil || u.Scheme == "" || u.Host == "" { return Config{}, fmt.Errorf("target %q has an invalid HTTP address", t.Name) } } else if _, _, err := net.SplitHostPort(t.Address); err != nil { return Config{}, fmt.Errorf("target %q has an invalid TCP address", t.Name) }; if t.IntervalSeconds <= 0 { t.IntervalSeconds = 30 }; if t.TimeoutSeconds <= 0 { t.TimeoutSeconds = 10 }; if t.TimeoutSeconds > t.IntervalSeconds { return Config{}, fmt.Errorf("target %q timeout must not exceed interval", t.Name) } }
	return cfg, nil
}

func monitor(ctx context.Context, t Target, store *storage.Store) { interval := time.Duration(t.IntervalSeconds) * time.Second; timeout := time.Duration(t.TimeoutSeconds) * time.Second; ticker := time.NewTicker(interval); defer ticker.Stop(); check := func() { checkCtx, cancel := context.WithTimeout(ctx, timeout); defer cancel(); var result checker.Result; if t.Type == "tcp" { result = checker.TCP(checkCtx, t.Address, timeout) } else { result = checker.HTTP(checkCtx, t.Address, timeout) }; if err := store.Add(t.Name, result); err != nil { log.Printf("store %q: %v", t.Name, err) } }; check(); for { select { case <-ctx.Done(): return; case <-ticker.C: check() } } }
func retentionLoop(ctx context.Context, store *storage.Store, days int) { run := func() { if err := store.DeleteBefore(time.Now().AddDate(0, 0, -days)); err != nil { log.Printf("retention cleanup: %v", err) } }; run(); ticker := time.NewTicker(24 * time.Hour); defer ticker.Stop(); for { select { case <-ctx.Done(): return; case <-ticker.C: run() } } }
func healthHandler(w http.ResponseWriter, r *http.Request) { if r.Method != http.MethodGet { http.Error(w, "method not allowed", http.StatusMethodNotAllowed); return }; _, _ = w.Write([]byte("ok\n")) }
func readyHandler(store *storage.Store) http.HandlerFunc { return func(w http.ResponseWriter, r *http.Request) { if r.Method != http.MethodGet { http.Error(w, "method not allowed", http.StatusMethodNotAllowed); return }; if err := store.Ping(); err != nil { http.Error(w, "not ready", http.StatusServiceUnavailable); return }; _, _ = w.Write([]byte("ready\n")) } }
func recentHandler(store *storage.Store) http.HandlerFunc { return func(w http.ResponseWriter, r *http.Request) { if r.Method != http.MethodGet { http.Error(w, "method not allowed", http.StatusMethodNotAllowed); return }; rows, err := store.Recent(100); if err != nil { http.Error(w, "database error", 500); return }; defer rows.Close(); jsonResponse(w, readResults(rows)) } }
func latestHandler(store *storage.Store) http.HandlerFunc { return func(w http.ResponseWriter, r *http.Request) { if r.Method != http.MethodGet { http.Error(w, "method not allowed", http.StatusMethodNotAllowed); return }; rows, err := store.Latest(); if err != nil { http.Error(w, "database error", 500); return }; defer rows.Close(); out := readResults(rows); sort.Slice(out, func(i, j int) bool { return out[i].Target < out[j].Target }); jsonResponse(w, out) } }
func readResults(rows interface{ Next() bool; Scan(...any) error }) []apiResult { out := []apiResult{}; for rows.Next() { var x apiResult; var up int; if err := rows.Scan(&x.Target, &up, &x.LatencyMs, &x.StatusCode, &x.Error, &x.CheckedAt); err == nil { x.Up = up == 1; out = append(out, x) } }; return out }
func jsonResponse(w http.ResponseWriter, value any) { w.Header().Set("Content-Type", "application/json; charset=utf-8"); _ = json.NewEncoder(w).Encode(value) }
func loggingMiddleware(next http.Handler) http.Handler { return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { started := time.Now(); next.ServeHTTP(w, r); log.Printf("%s %s %s", r.Method, r.URL.Path, time.Since(started)) }) }
