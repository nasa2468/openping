package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestLoadConfig(t *testing.T) {
	path := filepath.Join(t.TempDir(), "config.yaml")
	data := "targets:\n  - name: site\n    type: http\n    address: https://example.com\n    interval_seconds: 30\n    timeout_seconds: 5\n"
	if err := os.WriteFile(path, []byte(data), 0600); err != nil { t.Fatal(err) }
	cfg, err := loadConfig(path); if err != nil { t.Fatal(err) }
	if cfg.Server.Address != ":8080" || cfg.RetentionDays != 30 || len(cfg.Targets) != 1 { t.Fatalf("unexpected config: %+v", cfg) }
}

func TestLoadConfigRejectsInvalidTarget(t *testing.T) {
	path := filepath.Join(t.TempDir(), "config.yaml")
	if err := os.WriteFile(path, []byte("targets:\n  - name: site\n    type: smtp\n    address: example.com\n"), 0600); err != nil { t.Fatal(err) }
	if _, err := loadConfig(path); err == nil { t.Fatal("expected invalid type error") }
}
