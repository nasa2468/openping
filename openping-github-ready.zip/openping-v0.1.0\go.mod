module github.com/YOUR_GITHUB_USERNAME/openping

go 1.23

require (
	github.com/mattn/go-sqlite3 v1.14.24
	gopkg.in/yaml.v3 v3.0.1
)
