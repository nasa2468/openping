// Package checker implements network availability checks.
package checker

import (
	"context"
	"net"
	"net/http"
	"time"
)

// Result is the outcome of a target check.
type Result struct {
	Up         bool
	LatencyMs  int64
	StatusCode int
	Error      string
}

// HTTP checks an HTTP or HTTPS endpoint. A 2xx or 3xx response is considered up.
func HTTP(ctx context.Context, address string, timeout time.Duration) Result {
	client := &http.Client{
		Timeout: timeout,
		CheckRedirect: func(_ *http.Request, _ []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}
	start := time.Now()
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, address, nil)
	if err != nil {
		return Result{Error: err.Error()}
	}
	req.Header.Set("User-Agent", "OpenPing/1.0")
	resp, err := client.Do(req)
	latency := time.Since(start).Milliseconds()
	if err != nil {
		return Result{LatencyMs: latency, Error: err.Error()}
	}
	defer resp.Body.Close()
	return Result{Up: resp.StatusCode >= 200 && resp.StatusCode < 400, LatencyMs: latency, StatusCode: resp.StatusCode}
}

// TCP checks whether a TCP address accepts a connection.
func TCP(ctx context.Context, address string, timeout time.Duration) Result {
	start := time.Now()
	conn, err := (&net.Dialer{Timeout: timeout}).DialContext(ctx, "tcp", address)
	latency := time.Since(start).Milliseconds()
	if err != nil {
		return Result{LatencyMs: latency, Error: err.Error()}
	}
	_ = conn.Close()
	return Result{Up: true, LatencyMs: latency}
}
