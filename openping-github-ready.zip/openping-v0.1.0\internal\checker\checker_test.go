package checker

import (
	"context"
	"net"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func TestHTTP(t *testing.T) {
	success := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) { w.WriteHeader(http.StatusNoContent) }))
	defer success.Close()
	result := HTTP(context.Background(), success.URL, time.Second)
	if !result.Up || result.StatusCode != http.StatusNoContent { t.Fatalf("unexpected success result: %+v", result) }

	failure := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) { w.WriteHeader(http.StatusServiceUnavailable) }))
	defer failure.Close()
	result = HTTP(context.Background(), failure.URL, time.Second)
	if result.Up || result.StatusCode != http.StatusServiceUnavailable { t.Fatalf("unexpected failure result: %+v", result) }
}

func TestTCP(t *testing.T) {
	listener, err := net.Listen("tcp", "127.0.0.1:0"); if err != nil { t.Fatal(err) }; defer listener.Close()
	go func() { conn, err := listener.Accept(); if err == nil { _ = conn.Close() } }()
	result := TCP(context.Background(), listener.Addr().String(), time.Second)
	if !result.Up { t.Fatalf("expected up result: %+v", result) }
}
