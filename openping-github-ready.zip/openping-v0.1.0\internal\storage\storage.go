// Package storage persists monitoring results in SQLite.
package storage

import (
	"database/sql"
	"time"

	"github.com/YOUR_GITHUB_USERNAME/openping/internal/checker"
	_ "github.com/mattn/go-sqlite3"
)

type Store struct{ DB *sql.DB }

func Open(path string) (*Store, error) {
	db, err := sql.Open("sqlite3", path+"?_busy_timeout=5000&_journal_mode=WAL")
	if err != nil { return nil, err }
	db.SetMaxOpenConns(1)
	_, err = db.Exec(`CREATE TABLE IF NOT EXISTS checks (id INTEGER PRIMARY KEY AUTOINCREMENT,target TEXT NOT NULL,up INTEGER NOT NULL,latency_ms INTEGER NOT NULL,status_code INTEGER NOT NULL,error TEXT NOT NULL,checked_at DATETIME NOT NULL); CREATE INDEX IF NOT EXISTS idx_checks_target_time ON checks(target, checked_at);`)
	if err != nil { _ = db.Close(); return nil, err }
	return &Store{DB: db}, nil
}

func (s *Store) Close() error { return s.DB.Close() }
func (s *Store) Ping() error { return s.DB.Ping() }

func (s *Store) Add(target string, r checker.Result) error {
	up := 0; if r.Up { up = 1 }
	_, err := s.DB.Exec(`INSERT INTO checks(target,up,latency_ms,status_code,error,checked_at) VALUES(?,?,?,?,?,?)`, target, up, r.LatencyMs, r.StatusCode, r.Error, time.Now().UTC())
	return err
}

func (s *Store) Recent(limit int) (*sql.Rows, error) {
	if limit < 1 || limit > 1000 { limit = 100 }
	return s.DB.Query(`SELECT target,up,latency_ms,status_code,error,checked_at FROM checks ORDER BY id DESC LIMIT ?`, limit)
}

func (s *Store) Latest() (*sql.Rows, error) {
	return s.DB.Query(`SELECT c.target,c.up,c.latency_ms,c.status_code,c.error,c.checked_at FROM checks c JOIN (SELECT target,MAX(id) id FROM checks GROUP BY target) latest ON latest.id=c.id ORDER BY c.target`)
}

func (s *Store) DeleteBefore(t time.Time) error { _, err := s.DB.Exec(`DELETE FROM checks WHERE checked_at < ?`, t.UTC()); return err }
