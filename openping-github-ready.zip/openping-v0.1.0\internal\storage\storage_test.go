package storage

import (
	"path/filepath"
	"testing"
	"time"

	"github.com/YOUR_GITHUB_USERNAME/openping/internal/checker"
)

func TestStoreResults(t *testing.T) {
	store, err := Open(filepath.Join(t.TempDir(), "openping.db")); if err != nil { t.Fatal(err) }; defer store.Close()
	if err := store.Add("example", checker.Result{Up: true, LatencyMs: 12, StatusCode: 200}); err != nil { t.Fatal(err) }
	rows, err := store.Latest(); if err != nil { t.Fatal(err) }; defer rows.Close()
	if !rows.Next() { t.Fatal("expected result") }
	var target, message string; var up, status int; var latency int64; var checked time.Time
	if err := rows.Scan(&target, &up, &latency, &status, &message, &checked); err != nil { t.Fatal(err) }
	if target != "example" || up != 1 || latency != 12 || status != 200 { t.Fatalf("unexpected row: %s %d %d %d", target, up, latency, status) }
}
